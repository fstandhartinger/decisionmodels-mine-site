import copy
import json
import os
import pathlib
import tempfile
import unittest
from types import SimpleNamespace
from unittest.mock import patch
from reaxlib import cmd_install as install

ROOT = pathlib.Path(__file__).resolve().parents[1]
D = json.loads((ROOT / 'releases/current.json').read_text())


def args(home, **kwargs):
    return SimpleNamespace(home=str(home), mode=kwargs.get('mode', 'localnet'), pool=kwargs.get('pool', 's1-fast'), confirm_mainnet=kwargs.get('confirm_mainnet', False), **{k:v for k,v in kwargs.items() if k not in ('mode','pool','confirm_mainnet')})


class InstallTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.home = pathlib.Path(self.tmp.name) / 'state'
        patcher = patch.object(install.sys, 'version_info', (3, 10, 12))  # tools need Python 3.10 even if the controller runs on 3.8
        patcher.start()
        self.addCleanup(patcher.stop)
    def tearDown(self):
        self.tmp.cleanup()
    def test_launch_gate_creates_nothing(self):
        with patch.object(install, 'descriptor', return_value=D), patch.object(install, 'runner') as runner:
            for mode in ('testnet', 'mainnet'):
                self.assertEqual(install.install(args(self.home, mode=mode)).code(), 12)
            runner.assert_not_called()
        self.assertFalse(self.home.exists())
    def test_confirmation_is_separate(self):
        d = copy.deepcopy(D)
        d['status'].update(live=True, netuid=1)
        with patch.object(install, 'descriptor', return_value=d):
            self.assertEqual(install.install(args(self.home, mode='mainnet')).code(), 11)
        self.assertFalse(self.home.exists())
    def test_localnet_idempotent_private_permissions(self):
        source = pathlib.Path(self.tmp.name) / 'source'
        (source / 'scripts/localnet').mkdir(parents=True)
        (source / 'scripts/localnet/start.sh').touch()
        with patch.object(install, 'descriptor', return_value=D), patch.object(install, 'prepare_tools', return_value=None), patch.dict(os.environ, REAX_SOURCE_DIR=str(source)):
            self.assertTrue(install.install(args(self.home)).ok)
            secret = (self.home / 'secrets/runtime-token').read_text()
            self.assertTrue(install.install(args(self.home)).ok)
            self.assertEqual(secret, (self.home / 'secrets/runtime-token').read_text())
            self.assertEqual((self.home / 'secrets/runtime-token').stat().st_mode & 0o777, 0o600)
        self.assertFalse((self.home / 'compose.yml').exists())
    def test_render_digests_and_least_wallet_mounts(self):
        self.home.mkdir()
        d = copy.deepcopy(D)
        d['images']['digests'] = {'miner':'sha256:abc', 's1_fast_runtime':'sha256:def'}
        install.render(self.home, d, {'pool':'s1-fast','network':'finney','netuid':4, 'wallet_path':'/owned/wallets','wallet_name':'x','hotkey_name':'h'})
        text = (self.home / 'compose.yml').read_text()
        self.assertIn('@sha256:abc', text)
        self.assertIn('@sha256:def', text)
        self.assertIn('/owned/wallets/x/hotkeys/h:', text)
        self.assertIn('/owned/wallets/x/coldkeypub.txt:', text)
        self.assertNotIn('/owned/wallets:/', text)
        self.assertNotIn('ports:', text)
        self.assertNotIn('/coldkey:', text)
        self.assertEqual(text.count('network_mode: host'), 2)
        self.assertIn('http://127.0.0.1:8101', (self.home / 'miner.env').read_text())
        self.assertEqual((self.home / 'miner.env').stat().st_mode & 0o777, 0o600)
    def test_wallet_mount_cannot_escape_to_coldkey(self):
        self.home.mkdir()
        with self.assertRaises(ValueError):
            install.render(self.home, D, {'pool':'s1-fast','network':'finney','netuid':4,'hotkey_name':'../../coldkey'})
    def test_tools_satisfied_skips_pip(self):
        (self.home / 'venv/bin').mkdir(parents=True)
        (self.home / 'venv/bin/python').touch()
        with patch.object(install, 'runner', return_value=(0,'','')) as run:
            install.prepare_tools(self.home, D)
        self.assertEqual(run.call_count, 1)
        self.assertIn('bittensor==11.1.0', run.call_args[0][0])
    def test_low_disk_stops_before_tools(self):
        with patch.object(install, 'descriptor', return_value=D), patch.object(install.shutil, 'disk_usage', return_value=SimpleNamespace(free=1)), patch.object(install, 'runner') as run:
            self.assertEqual(install.install(args(self.home)).code(), 10)
            run.assert_not_called()
    def test_unknown_pool(self):
        with patch.object(install, 'descriptor', return_value=D):
            self.assertEqual(install.install(args(self.home, pool='missing')).code(), 2)
