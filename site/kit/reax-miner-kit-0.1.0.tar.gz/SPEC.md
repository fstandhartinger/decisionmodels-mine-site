# reaxctl — design contract (lead-owned; workers implement, do not change without asking)

`reaxctl` is the one tool a person's agent (Claude Code, Codex CLI, …) runs to set a machine up for mining on the REAX subnet
(Bittensor) via Decision Models. It is a Python 3.8+ **stdlib-only** controller (`reaxctl`, executable, `#!/usr/bin/env python3`, plus the bundled `reaxlib/` package);
no pip needed to run the controller. Miner/rehearsal tools use the descriptor's Python minimum in an isolated venv. Linux x86_64 (incl. WSL2) is the mining platform; macOS/Windows get `doctor`, wallet guidance and the
localnet rehearsal. Written for AGENTS first: every command has `--json`, is idempotent, never prompts unless run on a TTY
without `--yes`, and ends with `next` steps.

## Hard safety rules (enforced in code AND repeated in output)
1. reaxctl never creates, reads, prints, stores or asks for a COLDKEY or any recovery phrase. It only ever handles a hotkey file
   on the mining box and the public `coldkeypub.txt`. (Localnet rehearsal uses throw-away dev accounts only.)
2. reaxctl never spends real TAO, never signs a payment, never registers on mainnet. Registration is a `needs_human` step.
3. Mainnet/testnet are refused unless the release descriptor says so (`status.live` + `netuid`), and `--mode mainnet` needs
   `--confirm-mainnet` typed by the human-approved flow. Default mode = `localnet` (rehearsal).
4. No earnings/price statements anywhere in output. Rewards = "variable subnet emissions; can be zero".
5. Never publish the sidecar ports (8101/8102/8000); miner port default 8091 only.
6. No telemetry. Network calls only to: the descriptor URL(s), Docker registry/Hugging Face (pinned revisions), the chain endpoint,
   and (only with `--probe-ip`) one public-IP echo service. Everything it contacts is listed in `reaxctl net-policy --json`.

## Output contract
Every command accepts `--json`. With `--json`, stdout is exactly ONE JSON object, human logging goes to stderr:
```
{"schema":"reaxctl/1","command":"doctor","ok":true,"status":"ok|needs_human|blocked|error",
 "summary":"one plain sentence","data":{...},"warnings":[...],
 "needs_human":null | {"action":"…","why":"…","steps":["…"],"cost":{"kind":"none|tao|fiat","note":"…"},"link":"https://…"},
 "next":[{"command":"reaxctl install --pool s1-fast","why":"…"}]}
```
Exit codes: 0 ok · 2 usage · 10 requirement unmet (hardware/OS) · 11 needs_human · 12 not available yet (launching soon / images
private / mainnet closed) · 13 network/download failure · 20 verification failed · 1 unexpected. Without `--json` print the same
information as short plain text. Secrets are never printed (tokens are written to 0600 files; show path only).

## State
`$REAX_HOME` (default `~/.reax-miner`): `config.json` (mode, pool, netuid, network, wallet_name, hotkey_name, miner_port,
external_ip, release_id), `state.json` (completed steps + timestamps, for resume), `releases/current.json` (cache),
`compose.yml`, `miner.env` (0600), `secrets/runtime-token` (0600, `openssl rand -hex 32` equivalent via `secrets`),
`weights/<pool>/`, `logs/`, `venv/` (tools: `huggingface_hub`, `bittensor==11.1.0`, `typer<0.27.2`). Wallets stay in
`~/.bittensor/wallets/<wallet_name>/` (bittensor default). `reaxctl uninstall` never touches wallets.

## Release descriptor (`releases/current.json`, schema `reax-release/1`)
Single source of truth for pins. Fetched from `$REAX_RELEASES_URL` (default `https://mine.decisionmodels.io/releases/current.json`),
cached, fallback to the copy bundled in the kit. Fields: `release_id`, `status{launch_status:"launching_soon|live", live:bool,
netuid:int|null, network:"finney", testnet_netuid:int|null, notes}`, `minimum_release`, `images{miner,s1_fast_runtime,
s1_pro_runtime, tag, digests{…}|null, public:bool}`, `source{git, ref, public:bool}`, `pools[]` (id, model, weights{repo,revision,
gated,size_gb}, manifest_id, commitment, gpu{min_vram_gb,max_vram_gb,count,vendor,measured[]}, sidecar_port, enabled_at_launch),
`requirements{cpu_cores,ram_gb,disk_gb{pool},driver_min,open_ports,never_publish_ports,python_min}`, `links{…}`,
`update{channel, auto_safe:bool, manifest_change_requires_confirm:true}`. `status.live=false` ⇒ real-network modes exit 12.

## Commands
- `doctor [--probe-ip]` — facts + verdict: OS (linux/macos/wsl2/windows-native), arch, CPU, RAM, disk free in $REAX_HOME,
  GPUs (`nvidia-smi --query-gpu=name,memory.total,driver_version --format=csv,noheader,nounits`; fall back to `lspci`; detect AMD/Apple
  and say unsupported), driver vs CUDA-13 floor (R580), Docker (client, daemon reachable, user in `docker` group,
  `docker info` runtimes incl. nvidia, compose plugin), NVIDIA container toolkit, python version, systemd available, NTP sync
  (`timedatectl show -p NTPSynchronized`, chronyc fallback), miner port free, public IP (only with `--probe-ip`), Hugging Face
  reachability. `data.eligible_pools[]` with reasons (VRAM vs `min_vram_gb`/`max_vram_gb`), `data.rehearsal_possible`, `data.blockers[]`
  each with a concrete `fix`. Pure read-only.
- `plan [--pool P] [--mode M]` — ordered steps with `who: agent|human`, `cost`, `reversible`, `command`. Dry run.
- `install [--pool s1-fast] [--mode localnet|testnet|mainnet] [--yes]` — creates `$REAX_HOME`, tool venv, runtime token, renders
  `compose.yml`+`miner.env`, pulls images by digest (docker) or prepares the no-docker rehearsal from `source`, downloads the pinned
  weights (docker modes only) with a size/disk preflight. Resumable.
- `wallet hotkey [--wallet-name reax] [--hotkey-name miner1]` — creates a hotkey-only wallet (no coldkey!) using the tool venv;
  prints the SS58 address, never the phrase. `wallet coldkeypub --ss58 <addr>` writes `coldkeypub.txt` (public) with the stdlib
  SS58→public-key conversion; verifies checksum. `wallet status` — which files exist, permissions, addresses.
- `register` — mainnet/testnet: returns `needs_human` with the exact registration page/steps and the hotkey address (human pays and
  signs). Localnet: performs the registration against the local chain with the dev funding account (test TAO only).
- `start | stop | restart | status | logs [--lines N]` — docker compose (`docker`) or process manager (rehearsal). `status` = containers,
  `GET /health` (protocol/version/model/manifest_id), commitment published?, registered on chain?, last validator query / score if visible.
- `verify` — end-to-end checklist with pass/fail per item (health, commitment, registration, validator rounds seen, clock skew, sidecar
  not publicly reachable from the host's own public IP if `--probe-ip`). exit 20 on failure with the failing item's fix.
- `service install|uninstall|status` — systemd (system unit if root/sudo works non-interactively, else `--user` unit with
  `loginctl enable-linger` hint as needs_human), launchd plist on macOS (rehearsal / miner-process only). Unit runs
  `reaxctl run` (foreground supervisor = `docker compose up` in foreground), restarts on failure, logs to journal.
- `update check|apply|timer install|timer uninstall` — compares installed `release_id`/`manifest_id` to the descriptor.
  `apply` for same-manifest updates is automatic when `update.auto_safe`; a **manifest change** (score restarts from zero, validators
  refuse unknown manifests) always returns `needs_human` unless `--accept-manifest-change`. Timer = systemd timer running
  `reaxctl update apply --auto --json` daily with random delay. Rollback keeps the previous compose+digests.
- `localnet up|down|status` — no-docker rehearsal: local subtensor + hash runtime miner + local validator from the descriptor's
  `source` (a git checkout/tarball); funds throw-away accounts. Used by tests and by "try it first".
- `spec` (prints this machine spec: commands, modes, step graph), `agent-rules`, `net-policy`, `version`.

## Step graph (what an agent follows; also published as /mine.json)
doctor → choose mode (default localnet rehearsal) → install → wallet hotkey → [human] create coldkey (Talisman/btcli on another machine) →
wallet coldkeypub → [human] fund + register (reax.dev/register or btcli) → start → verify → service install → update timer.
Mainnet steps are listed but blocked while `status.live=false`.
