# REAX miner kit

`reaxctl` helps people and their agents prepare a miner for the REAX Bittensor subnet via Decision Models. The controller uses Python 3.8+ and the standard library; mining and rehearsal tools need Python 3.10+ in an isolated venv.

REAX is not live on mainnet yet. The native localnet rehearsal works today with an authorized subnet source checkout. Images and subnet source remain private until launch, so a public download of this kit alone cannot run the rehearsal yet. Mainnet and testnet installation, registration and startup return exit 12 while the release descriptor is closed. Protocol and scoring documentation belongs at [reax.dev](https://reax.dev/mine/).

## Quickstart for people

Start at https://mine.decisionmodels.io for the kit download and current launch status. After obtaining and verifying the kit, run from its directory:

```sh
./reaxctl doctor
./reaxctl plan --mode localnet
./reaxctl net-policy --json
```

With access to the pinned subnet checkout, set `REAX_SOURCE_DIR` to its absolute path, then:

```sh
./reaxctl install --mode localnet
./reaxctl localnet up
./reaxctl wallet status
./reaxctl verify
./reaxctl localnet down
```

The rehearsal runs a local chain, a hash runtime miner and a validator using disposable development identities and test TAO. It demonstrates the onboarding flow; it does not measure production model serving. The first run fetches a pinned native chain image and installs tool dependencies. State defaults to `~/.reax-miner`; `--home /absolute/path` or `REAX_HOME` selects another location. Existing user wallets stay in `~/.bittensor/wallets`.

## Quickstart for agents

Give your agent this one-sentence prompt:

> Set up this machine for mining at Decision Models by REAX: https://mine.decisionmodels.io.

Read [AGENTS.md](AGENTS.md), then use `./reaxctl spec --json`, `./reaxctl agent-rules --json` and `./reaxctl doctor --json`. Every command supports `--json` and returns one `reaxctl/1` object with status, warnings, human actions and next steps. `--yes` does not authorize payments or key disclosure.

## Commands

| Command | Purpose |
| --- | --- |
| `doctor [--pool P] [--probe-ip]` | Read-only host requirements; optional explicit network probes |
| `plan --mode M --pool P` | Ordered setup steps, costs, owners and launch blocks |
| `install --mode M --pool P` | Prepare pinned tools, source or images and weights |
| `wallet hotkey` | Create only a hotkey; never show its phrase |
| `wallet coldkeypub --ss58 ADDRESS` | Import a public coldkey address |
| `wallet status` | Public addresses, file permissions and rehearsal wallet location |
| `register --mode M` | Rehearsal registration or human real-network handoff |
| `start / stop / restart / run` | Manage the installed miner; `run` supervises in foreground |
| `status / logs --lines N / verify` | Inspect runtime and verify observable readiness |
| `localnet up / down / status` | Manage the native rehearsal |
| `service install / uninstall / status` | Manage a systemd service or macOS LaunchAgent |
| `update check / apply` | Compare pins, apply safe updates, retain rollback files |
| `update timer install / uninstall` | Manage the daily systemd update timer |
| `spec / agent-rules / net-policy / version` | Machine contract, safety rules, destinations and version |

Exit codes: 0 success, 2 usage, 10 unmet requirement, 11 human action, 12 unavailable until launch, 13 download/network failure, 20 verification failure, 1 unexpected error.

## Modes and platforms

- **localnet** is the default. No Docker, model weights or GPU required. The native chain rehearsal is currently verified on Linux x86_64; other platforms can inspect the controller, but native runtime compatibility needs verification.
- **testnet** requires a live descriptor and a testnet netuid. Registration remains a human action using test TAO.
- **mainnet** requires a live descriptor and netuid, plus human-approved `--confirm-mainnet` during installation. Registration and any payment happen in the person's own wallet.

Real mining requires Linux x86_64 with NVIDIA, driver R580+ and the NVIDIA Docker runtime. WSL2 support is conditional on NVIDIA GPU passthrough, compatible drivers and Docker access. macOS is supported as a controller only; its GPU cannot mine with this kit. AMD GPUs are unsupported. `doctor` checks the descriptor's pool requirements; s1-pro is listed for reference and is disabled at launch.

## Safety and network access

The kit handles only hotkeys and public coldkey addresses. Never provide a coldkey, recovery phrase or signing authority. It never spends real TAO or signs a real registration payment. A person approves registration in their own wallet. Rehearsal funding uses disposable local development identities. Secret files use mode 0600. No telemetry is sent. Administrator actions are shown explicitly; the kit does not invoke interactive sudo.

Expose only the real miner port (default 8091). Keep runtime ports 8101, 8102 and 8000 private. The rehearsal miner binds a local private IPv4 address; keep its port range within your trusted network.

`./reaxctl net-policy --json` lists the configured destinations and conditions. The bundled descriptor currently lists:

| Destination | Use |
| --- | --- |
| `mine.decisionmodels.io/releases/current.json` | Explicit descriptor refresh |
| `ghcr.io` | Pinned miner/runtime images and native localnet chain image |
| `huggingface.co`, `cdn-lfs.huggingface.co`, `cas-bridge.xethub.hf.co` | Pinned weights and optional reachability check |
| `github.com/fstandhartinger/reax-subnet` | Pinned source, when public |
| `pypi.org`, `files.pythonhosted.org` | Isolated tool dependencies |
| Loopback chain endpoint | Rehearsal chain (configured port; default localnet base 19951) |
| `entrypoint-finney.opentensor.ai:443` | Mainnet chain when enabled |
| `test.finney.opentensor.ai:443` | Testnet chain when enabled |
| `api.ipify.org` | Public-IP echo only with `--probe-ip` |

Docker and package hosts may use their download infrastructure. A custom descriptor URL changes the listed release endpoint. The registration page is opened by the person, not used to submit a CLI transaction.

## Releases, pins and verification

[releases/current.json](releases/current.json) selects source refs, image tags/digests, model revisions and approved manifests. [Descriptor documentation](releases/README.md) explains the fields. `update check` compares installed pins. Safe same-manifest updates can run automatically; the optional timer checks daily. A manifest change resets the score to zero and requires explicit human confirmation with `--accept-manifest-change`. The timer cannot provide that approval. Previous compose, environment and configuration files remain under the state directory's `rollback/`.

Use the git tag and SHA256 checksum published on https://mine.decisionmodels.io to verify the exact release before running it. Check out that tag and compare the downloaded artifact with `sha256sum`; a missing published tag or checksum is not verification. Kit version 0.1.0 is the first release preparation; publication of the tag, artifact and site checksum is a separate release step.

## Contributing and issues

Open an issue in this repository with the command, kit version, OS and redacted JSON output. Never attach keys, phrases, runtime tokens or wallet files. For changes, read [AGENTS.md](AGENTS.md), run the unit tests, and submit a focused pull request. Report security issues privately as described in [SECURITY.md](SECURITY.md). This kit is MIT licensed; subnet source and third-party dependencies have their own terms.
