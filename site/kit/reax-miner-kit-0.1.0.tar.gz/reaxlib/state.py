"""State paths and private, atomic JSON persistence."""
from __future__ import annotations

import json
import os
from pathlib import Path
import tempfile


def home(args=None):
    override = args if isinstance(args, (str, Path)) else getattr(args, 'home', None)
    path = Path(override or os.environ.get('REAX_HOME') or '~/.reax-miner').expanduser().resolve()
    if any(c in str(path) for c in ('\n', '\r', '\0')):
        raise ValueError('State paths cannot contain control characters')
    return path


def read_json(path, default=None):
    try:
        with Path(path).open(encoding='utf-8') as stream:
            value = json.load(stream)
        return value
    except (OSError, ValueError):
        return {} if default is None else default


def write_text(path, value, mode=0o600):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    fd, temp = tempfile.mkstemp(prefix='.' + path.name, dir=str(path.parent))
    try:
        os.fchmod(fd, mode)
        with os.fdopen(fd, 'w', encoding='utf-8') as stream:
            stream.write(value)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temp, path)
    finally:
        if os.path.exists(temp):
            os.unlink(temp)


def write_json(path, value, mode=0o600):
    write_text(path, json.dumps(value, indent=2) + '\n', mode)


def load_config(args=None):
    value = read_json(home(args) / 'config.json')
    return value if isinstance(value, dict) else {}


def save_config(args, value):
    write_json(home(args) / 'config.json', value)


def load_state(args=None):
    value = read_json(home(args) / 'state.json')
    return value if isinstance(value, dict) else {}


def save_state(args, value):
    write_json(home(args) / 'state.json', value)


def mode(args=None):
    return getattr(args, 'mode', None) or load_config(args).get('mode', 'localnet')
