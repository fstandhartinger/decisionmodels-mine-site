"""Validated release pins; network fetch is explicit so doctor stays offline."""
from __future__ import annotations

import json
import os
import re
from pathlib import Path
import urllib.request

from . import state

DEFAULT_URL = 'https://mine.decisionmodels.io/releases/current.json'
BUNDLED = Path(__file__).resolve().parent.parent / 'releases' / 'current.json'


def url():
    return os.environ.get('REAX_RELEASES_URL', DEFAULT_URL)


def validate(value):
    def require(obj, keys):
        if not isinstance(obj, dict) or any(key not in obj for key in keys):
            raise ValueError('release descriptor is missing required fields')
    require(value, ['schema', 'release_id', 'status', 'minimum_release', 'images', 'source', 'pools', 'requirements', 'links', 'update'])
    if not isinstance(value['release_id'], str) or not value['release_id'] or not isinstance(value['minimum_release'], str):
        raise ValueError('invalid release identifier')
    if value['schema'] != 'reax-release/1':
        raise ValueError('unsupported release descriptor schema')
    require(value['status'], ['launch_status', 'live', 'netuid', 'network', 'testnet_netuid'])
    if value['status']['launch_status'] not in ('launching_soon', 'live') or not isinstance(value['status']['network'], str):
        raise ValueError('invalid launch status or network')
    if not isinstance(value['status']['live'], bool):
        raise ValueError('descriptor live must be boolean')
    for key in ('netuid', 'testnet_netuid'):
        num = value['status'][key]
        if num is not None and (type(num) is not int or num < 0):
            raise ValueError('descriptor netuid must be a nonnegative integer or null')
    require(value['images'], ['miner', 's1_fast_runtime', 's1_pro_runtime', 'tag', 'digests', 'public'])
    if not isinstance(value['images']['public'], bool):
        raise ValueError('images public must be boolean')
    require(value['source'], ['git', 'ref', 'public'])
    if not isinstance(value['source']['git'], str) or not isinstance(value['source']['ref'], str) or not isinstance(value['source']['public'], bool):
        raise ValueError('invalid source pins')
    require(value['requirements'], ['cpu_cores', 'ram_gb', 'disk_gb', 'driver_min', 'open_ports', 'never_publish_ports', 'python_min'])
    requirements = value['requirements']
    for key in ('cpu_cores', 'ram_gb'):
        if type(requirements[key]) not in (int, float) or requirements[key] <= 0:
            raise ValueError('invalid host requirements')
    if not isinstance(requirements['disk_gb'], dict):
        raise ValueError('disk requirements must be an object')
    if not isinstance(requirements['python_min'], str) or not all(part.isdigit() for part in requirements['python_min'].split('.')):
        raise ValueError('invalid Python requirement')
    for key in ('open_ports', 'never_publish_ports'):
        if not isinstance(requirements[key], list) or any(type(port) is not int or not 1 <= port <= 65535 for port in requirements[key]):
            raise ValueError('invalid ports')
    require(value['links'], ['register'])
    if not isinstance(value['links']['register'], str) or not value['links']['register'].startswith('https://'):
        raise ValueError('invalid registration link')
    require(value['update'], ['channel', 'auto_safe', 'manifest_change_requires_confirm'])
    if not isinstance(value['pools'], list) or not value['pools']:
        raise ValueError('descriptor pools must be a nonempty list')
    ids = set()
    for pool in value['pools']:
        require(pool, ['id', 'model', 'weights', 'manifest_id', 'commitment', 'gpu', 'sidecar_port', 'enabled_at_launch'])
        if not isinstance(pool['id'], str) or not re.fullmatch(r'[A-Za-z0-9_-]+', pool['id']) or pool['id'] in ids:
            raise ValueError('invalid or duplicate pool id')
        ids.add(pool['id'])
        if type(requirements['disk_gb'].get(pool['id'])) not in (int, float) or requirements['disk_gb'][pool['id']] <= 0:
            raise ValueError('missing pool disk requirement')
        require(pool['weights'], ['repo', 'revision', 'gated', 'size_gb'])
        require(pool['gpu'], ['min_vram_gb', 'count', 'vendor'])
        if type(pool['gpu']['count']) is not int or pool['gpu']['count'] < 1 or not isinstance(pool['gpu']['vendor'], str):
            raise ValueError('invalid GPU count or vendor')
        if type(pool['gpu']['min_vram_gb']) not in (int, float) or pool['gpu']['min_vram_gb'] <= 0:
            raise ValueError('invalid GPU requirement')
        maximum = pool['gpu'].get('max_vram_gb')
        if maximum is not None and (type(maximum) not in (int, float) or maximum < pool['gpu']['min_vram_gb']):
            raise ValueError('invalid maximum VRAM')
    return value


def load(args=None, fetch=False, timeout=2):
    cache = state.home(args) / 'releases' / 'current.json'
    if fetch:
        try:
            with urllib.request.urlopen(url(), timeout=timeout) as response:
                value = validate(json.loads(response.read(1024 * 1024)))
            state.write_json(cache, value)
            return value
        except (OSError, ValueError):
            pass
    for path in (cache, BUNDLED):
        try:
            return validate(state.read_json(path))
        except ValueError:
            continue
    raise ValueError('no valid cached or bundled release descriptor')


load_descriptor = load
