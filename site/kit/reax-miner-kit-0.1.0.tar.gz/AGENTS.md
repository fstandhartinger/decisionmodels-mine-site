# Agents using or developing the REAX miner kit

Start at https://mine.decisionmodels.io and read https://mine.decisionmodels.io/agent.md for the published onboarding rules. This repository's safety contract is [SPEC.md](SPEC.md).

## Using the kit

- Default to localnet. Run `doctor`, `plan`, `agent-rules` and `net-policy` before setup; use `--json` to inspect results and exit codes.
- Never create, read, print, store or request a user coldkey or recovery phrase. Create only hotkeys. Import only public coldkey SS58 addresses. Do not upload wallet files or tokens.
- A person funds and approves any real payment or registration in their own wallet. `--yes` never authorizes spending. Mainnet installation needs human-approved `--confirm-mainnet`; closed networks remain blocked.
- Tell the person what needs administrator access and why before any sudo action. Do not run interactive sudo silently.
- Expose only miner port 8091 (or the configured miner port). Never publish sidecar ports 8101, 8102 or 8000. Keep rehearsal ports inside a trusted network.
- No telemetry, no unlisted network destinations, no token or reward-value claims. Consult `net-policy --json` for destination conditions.
- Manifest changes reset scores and require explicit human confirmation. Never add `--accept-manifest-change` to automatic timers.
- Preserve wallets and existing keys. Stop on conflicting keys or unknown encrypted files rather than overwriting them.

## Developing in this repository

Python 3.8+ syntax, standard library only on the controller path. Runtime dependencies belong in the isolated tool venv. Keep the JSON `reaxctl/1` envelope stable. Use list-form subprocess calls, never `shell=True`; keep secret outputs suppressed and private files 0600. Validate path components and contain archive extraction. Do not weaken SPEC safety requirements.

Run from the repository root:

```sh
python3 -m unittest discover -s tests
python3 -m py_compile reaxctl reaxlib/*.py
./reaxctl spec --json | python3 -m json.tool
./reaxctl doctor --json
```

Tests use fakes and temporary directories; do not introduce real wallet, Docker, chain or GPU operations into the unit suite. The CLI supports Python 3.8; actual miner tools require the descriptor's Python minimum (currently 3.10).

## File map

- `reaxctl`, `reaxlib/cli.py`, `result.py`: executable, parsers and output contract.
- `descriptor.py`, `state.py`: validated release data and atomic state storage.
- `cmd_info.py`, `cmd_doctor.py`, `sysprobe.py`: contract, network rules and read-only diagnosis/plan.
- `cmd_wallet.py`, `ss58.py`: hotkey-only wallet operations and public addresses.
- `cmd_install.py`, `cmd_runtime.py`, `localnet_ops.py`: installation, runtime and disposable rehearsal.
- `cmd_service.py`, `cmd_update.py`, `service/`: service templates and gated updates.
- `releases/`: descriptor and launch checklist; `docs/`: implementation notes.
- `tests/`: offline unit tests and host fixtures; `.github/workflows/ci.yml`: compatibility checks.
