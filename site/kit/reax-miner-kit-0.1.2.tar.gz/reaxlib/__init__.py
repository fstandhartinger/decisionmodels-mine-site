"""reaxctl: set up a machine for mining on the REAX subnet via Decision Models."""
__version__ = "0.1.2"
