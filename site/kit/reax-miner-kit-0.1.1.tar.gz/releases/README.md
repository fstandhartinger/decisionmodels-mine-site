# Release descriptor

`current.json` uses schema `reax-release/1`. It is bundled with the kit and may be cached under `<REAX_HOME>/releases/current.json`. Fetching is explicit; validation failure falls back to valid cached or bundled data. Default doctor is offline.

| Field | Meaning |
| --- | --- |
| `schema` | Exact schema identifier |
| `release_id`, `minimum_release` | Pinned release and declared minimum compatible release (minimum is metadata; not currently an enforced upgrade gate) |
| `status.launch_status`, `status.live` | `launching_soon` or `live`; real modes require `live:true` |
| `status.netuid`, `status.testnet_netuid`, `status.network` | Mainnet/testnet subnet IDs (null until assigned) and mainnet network name |
| `status.notes` | Human launch context |
| `images.miner`, `images.s1_fast_runtime`, `images.s1_pro_runtime` | Container repository names |
| `images.tag`, `images.digests`, `images.public` | Tag, per-image SHA256 digest map (or null), public-access flag; digest references take precedence |
| `source.git`, `source.ref`, `source.public` | Subnet repository, pinned ref and public availability |
| `pools[].id`, `model` | Safe pool identifier and descriptive model name |
| `pools[].weights` | HF `repo`, immutable `revision`, `gated`, `size_gb`; optional gate note |
| `pools[].manifest_id`, `commitment` | Approved scoring manifest and chain commitment |
| `pools[].gpu` | `min_vram_gb`, optional `max_vram_gb`, GPU `count`, `vendor`, measured hardware and optional notes |
| `pools[].sidecar_port`, `enabled_at_launch` | Private runtime port and launch eligibility |
| `requirements` | CPU cores, RAM GB, per-pool disk GB, driver/Python minimum, open ports and never-publish ports; OS/NTP notes |
| `tools` | Tool package constraints installed in the venv |
| `links` | Entry, guide, wallet, register, FAQ and project URLs |
| `update.channel`, `auto_safe`, `manifest_change_requires_confirm` | Release channel and update policy; manifest confirmation is enforced by the controller regardless of descriptor flags |

Optional descriptive notes do not grant execution authority. No descriptor flag authorizes a real payment. The CLI controller needs Python 3.8+; tool installation uses `requirements.python_min`.

## Launch-day checklist

1. Verify the actual assigned subnet IDs and release readiness. Set `status.live:true`, `status.launch_status:"live"`, `status.netuid` and, only when available, `status.testnet_netuid`. Keep unavailable network IDs null.
2. Publish the reviewed images; set immutable `images.tag`, every required `images.digests` entry and `images.public:true`. Verify unauthenticated pull access and loopback sidecar binding.
3. Publish reviewed subnet source; set `source.public:true` and its exact reviewed ref. Confirm tool and model revisions, gates and access permissions.
4. Verify launch-enabled pools, approved manifests/commitments, resource requirements, ports and links. Keep s1-pro disabled unless explicitly approved for launch.
5. Update `release_id`, declared `minimum_release` and release notes. Review manifest changes; they reset scores and require human confirmation.
6. Update the bundled descriptor and https://mine.decisionmodels.io/releases/current.json **and https://reax.dev/miner.json** together. Check their pins/status agree.
7. Run the unit suite, compatibility CI, public download checks and a controlled real miner rehearsal through human registration. Never perform payments from the kit.
8. Publish the reviewed kit git tag and artifact SHA256 on https://mine.decisionmodels.io. Verify the downloaded artifact against the published hash; retain release evidence.

Kit 0.1.1 validates descriptors before caching or consumption. Images must use ghcr.io;
live public images need sha256 digests. Tool keys are bittensor/typer/huggingface_hub, with
restricted version specs. Source URLs use HTTPS GitHub; refs are version tags or 40-hex
commits, and optional source.commit is checked after public checkout. Refreshed descriptors
must not downgrade known release versions or regress a live launch. Set --offline or
REAX_OFFLINE=1 to suppress refresh. The validated descriptor remains unsigned: HTTPS and
schema checks are not a cryptographic publisher signature.
