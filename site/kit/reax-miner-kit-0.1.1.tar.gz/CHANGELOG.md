# Changelog

## 0.1.1

Harden descriptor validation and refresh (one-hour cache, offline mode, bounded same-origin
HTTPS fetch and fallback warnings). Close the install manifest gate bypass. Isolate Python
helpers and restrict child environments. Protect hotkey creation, state directories and atomic
file writes; honour wallet overrides. Harden systemd and compose, redact and label untrusted
logs/health, validate external-IP probes, contain single-member tar extraction and guard PID
reuse. Localnet registration now explains its throw-away registration flow. Document policy
flag limitations, rollback locking/pruning and rehearsal RPC restrictions. Add offline regressions.

## 0.1.0

First release of the REAX miner kit. Native localnet rehearsal works with access to the pinned subnet source. Real-network operations remain blocked until launch. Includes read-only diagnosis, setup plans, hotkey-only wallet tooling, pinned installation, runtime verification, service management and confirmed manifest updates. Images and subnet source remain private until launch.
