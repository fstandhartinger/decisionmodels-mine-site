"""Output contract shared by every command (see SPEC.md, "Output contract")."""
from __future__ import annotations

import json
import sys
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

SCHEMA = "reaxctl/1"

EXIT_OK = 0
EXIT_USAGE = 2
EXIT_REQUIREMENT = 10
EXIT_NEEDS_HUMAN = 11
EXIT_NOT_AVAILABLE = 12
EXIT_NETWORK = 13
EXIT_VERIFY = 20
EXIT_UNEXPECTED = 1

_STATUS_EXIT = {"ok": EXIT_OK, "needs_human": EXIT_NEEDS_HUMAN, "blocked": EXIT_REQUIREMENT, "error": EXIT_UNEXPECTED}


@dataclass
class Result:
    command: str
    status: str = "ok"  # ok | needs_human | blocked | error
    summary: str = ""
    data: Dict[str, Any] = field(default_factory=dict)
    warnings: List[str] = field(default_factory=list)
    needs_human: Optional[Dict[str, Any]] = None
    next: List[Dict[str, str]] = field(default_factory=list)
    exit_code: Optional[int] = None  # overrides the status default (e.g. 12, 13, 20)

    @property
    def ok(self) -> bool:
        return self.status == "ok"

    def code(self) -> int:
        return self.exit_code if self.exit_code is not None else _STATUS_EXIT.get(self.status, EXIT_UNEXPECTED)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "schema": SCHEMA,
            "command": self.command,
            "ok": self.ok,
            "status": self.status,
            "summary": self.summary,
            "data": self.data,
            "warnings": self.warnings,
            "needs_human": self.needs_human,
            "next": self.next,
        }

    def render_text(self) -> str:
        if self.command == 'doctor':
            lines = ['Verdict', '  [{}] {}'.format(self.status, self.summary),
                     'What works today (rehearsal)',
                     '  ' + ('Localnet rehearsal is possible with the pinned source and tools.' if self.data.get('rehearsal_possible') else ('The practice run opens at launch: the miner source is private until then.' if self.data.get('rehearsal_capable') else 'Install the required Python version before rehearsal.')),
                     'What is needed for real mining']
            for item in self.data.get('blockers', []):
                lines.extend(['  ' + item['message'], '    Fix: ' + item['fix']])
            if not self.data.get('real_mining_possible'):
                lines.append('  Check the release descriptor: the network must be live, with a netuid and public images.')
            blocker_warnings = {item['message'] + ' Fix: ' + item['fix'] for item in self.data.get('blockers', [])}
            lines.extend('  Note: ' + w for w in self.warnings if w not in blocker_warnings)
            lines.append('Next')
            lines.extend('  ' + n.get('command', '') + '  # ' + n.get('why', '') for n in self.next)
            return '\n'.join(lines)
        lines = [f"[{self.status}] {self.summary}".rstrip()]
        if self.command == 'wallet status' and 'rehearsal_wallets' in self.data:
            rehearsal = self.data['rehearsal_wallets']
            lines.append('  Rehearsal wallets: ' + rehearsal['path'])
            for wallet in rehearsal['wallets']:
                lines.append('    ' + wallet['name'] + ': ' + str(wallet.get('hotkey_ss58') or wallet.get('coldkeypub_ss58') or 'public address unavailable'))
        for w in self.warnings:
            lines.append(f"  warning: {w}")
        if self.needs_human:
            nh = self.needs_human
            lines.append(f"  HUMAN ACTION: {nh.get('action', '')}")
            if nh.get("why"):
                lines.append(f"    why: {nh['why']}")
            for i, step in enumerate(nh.get("steps", []), 1):
                lines.append(f"    {i}. {step}")
            if nh.get("link"):
                lines.append(f"    link: {nh['link']}")
        for n in self.next:
            lines.append(f"  next: {n.get('command', '')}  # {n.get('why', '')}")
        return "\n".join(lines)


def emit(result: Result, as_json: bool) -> int:
    if as_json:
        sys.stdout.write(json.dumps(result.to_dict(), indent=2, sort_keys=False) + "\n")
    else:
        sys.stdout.write(result.render_text() + "\n")
    return result.code()
