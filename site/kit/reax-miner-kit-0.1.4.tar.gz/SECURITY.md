# Security reporting

Report suspected vulnerabilities privately to info@productivity-boost.com. Include the affected kit version, a concise description, impact and a minimal reproduction using disposable data. Do not send keys, recovery phrases, tokens or customer information. Please allow time for investigation before public disclosure.

Scope includes this kit's controller, release validation, state storage, installation, process management and wallet isolation. Subnet protocol and third-party packages have separate maintainers; include the relevant component when reporting. Only test systems you own or have permission to test. No bounty or payment is promised.
