"""Bounded, restartable REAX status publisher. Never signs chain transactions."""
import asyncio
import fcntl
import json
import os
import subprocess
import sys
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

from chain_check import read_chain

ROOT = Path(os.environ.get("REAX_WATCH_ROOT", Path(__file__).resolve().parents[1])).resolve()
REPOS = ROOT / "repos"
STATE = ROOT / "receipts" / "watcher-state.json"
DESCRIPTORS = {
    "reax-miner-kit": "releases/current.json",
    "decisionmodels-mine-site": "site/releases/current.json",
}
APPS = {"decisionmodels-mine-site": "qqmavc8g9kcuwpmkxv4bpdhw",
        "reax-site": "pxijaxhejm5vhkrgrcxkxmxb"}
ALLOWED = dict(DESCRIPTORS, **{"reax-site": "dev/static/chain-status.json"})
LIVE_NOTE = ("REAX Finney netuid 92 has started: alpha trading and alpha epochs are enabled. "
             "TAO emission share additionally requires the root-controlled emission flag. "
             "Source, images and public launch retain their separate release gates.")


def run(args, cwd=ROOT, timeout=120):
    env = {"HOME": str(Path.home()), "PATH": "/home/flori/.local/bin:/usr/local/bin:/usr/bin:/bin",
           "GIT_TERMINAL_PROMPT": "0", "AGENT_BOARD_NAME": "codex:reax-netuid92-20261010",
           "AGENT_BOARD_JOBDIR": str(ROOT)}
    if str(args[0]) == "gh" and os.environ.get("GH_TOKEN"):
        env["GH_TOKEN"] = os.environ["GH_TOKEN"]
    return subprocess.run([str(x) for x in args], cwd=cwd, timeout=timeout,
                          check=True, text=True, capture_output=True, env=env).stdout.strip()


def build_run(args, repo):
    """No network, real home or credentials inside repository builds/tests."""
    node_root = Path("/home/flori/.local/bin/node").resolve().parent.parent
    mounts = ["/usr", "/lib", "/lib64", "/etc/passwd", "/etc/group", str(ROOT / ".venv"), str(node_root)]
    command = ["/usr/bin/bwrap", "--unshare-net", "--die-with-parent"]
    for path in mounts:
        command += ["--ro-bind", path, path]
    command += ["--symlink", "usr/bin", "/bin", "--proc", "/proc", "--dev", "/dev",
                "--tmpfs", "/tmp", "--tmpfs", "/var", "--dir", "/var/log/nginx", "--dir", "/var/lib/nginx/body",
                "--bind", str(repo), str(repo), "--ro-bind", str(repo / ".git"), str(repo / ".git"), "--chdir", str(repo),
                "--clearenv", "--setenv", "HOME", "/tmp", "--setenv", "PATH",
                str(ROOT / ".venv/bin") + ":" + str(node_root / "bin") + ":/usr/bin:/usr/sbin:/bin", "--", *map(str, args)]
    return run(command, repo)


def atomic(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(data, indent=2) + "\n")
    os.replace(tmp, path)


def status_update(path, receipt):
    data = json.loads(path.read_text())
    status = data["status"]
    if status["netuid"] != 92 or status["network"] != "finney":
        raise ValueError("Descriptor target changed; refusing transition")
    status.update(live=True, launch_status="live", chain=receipt, notes=LIVE_NOTE)
    data["updated"] = receipt["checked_at"][:10]
    atomic(path, data)


def validate_local(repo, name):
    if name == "decisionmodels-mine-site":
        build_run([sys.executable, "scripts/build.py"], repo)
        build_run([sys.executable, "-m", "unittest", "discover", "-s", "tests"], repo)
        build_run(["node", "tests/webmcp-check.js"], repo)
    elif name == "reax-miner-kit":
        build_run([sys.executable, "-m", "unittest", "discover", "-s", "tests"], repo)
    else:
        build_run(["npm", "run", "build"], repo)
        build_run([sys.executable, "scripts/test-site.py"], repo)
        build_run(["node", "--test", "scripts/test-application.mjs"], repo)


def ci_gate(repo, name, head):
    """Real hosted successes, or confirmed never-started budget failures + real local tests."""
    slug = "fstandhartinger/" + name
    assert_head(repo, head)
    result = json.loads(run(["gh", "api", "repos/" + slug + "/commits/" + head + "/check-runs?per_page=100"], repo))
    checks = result["check_runs"]
    if result.get("total_count", len(checks)) > len(checks):
        raise ValueError("Incomplete CI coverage")
    required = [c for c in checks if c["name"].startswith("unittest (")] if name == "reax-miner-kit" else [c for c in checks if c["name"] == ("build-and-test" if name == "reax-site" else "site")]
    if len({c["name"] for c in required}) < (4 if name == "reax-miner-kit" else 1):
        raise ValueError("Expected CI jobs not registered yet")
    for check in checks:
        if check["conclusion"] in ("success", "skipped", "neutral"):
            continue
        if check["conclusion"] != "failure":
            raise ValueError("CI pending or cancelled")
        annotations = json.loads(run(["gh", "api", "repos/" + slug + "/check-runs/" + str(check["id"]) + "/annotations"], repo))
        failures = [a["message"] for a in annotations if a.get("annotation_level") == "failure"]
        job = json.loads(run(["gh", "api", "repos/" + slug + "/actions/jobs/" + str(check["id"])], repo))
        if failures != ["The job was not started because an Actions budget is preventing further use."] or job.get("steps") != []:
            raise ValueError("Actual hosted test failure; refusing merge")
    validate_local(repo, name)
    assert_head(repo, head)
    run(["gh", "api", "--method", "POST", "repos/" + slug + "/statuses/" + head,
         "-f", "state=success", "-f", "context=reax92/local-validation",
         "-f", "description=Isolated build/tests passed; hosted budget failures retained separately"], repo)
    statuses = json.loads(run(["gh", "api", "repos/" + slug + "/commits/" + head + "/status"], repo))["statuses"]
    if any(c["state"] != "success" for c in statuses):
        raise ValueError("Commit status not green")


def assert_head(repo, head):
    if run(["git", "rev-parse", "HEAD"], repo) != head or run(["git", "status", "--porcelain"], repo):
        raise ValueError("Local validated tree does not match PR head")


def prepare_repo(name, receipt):
    repo = REPOS / name
    if run(["git", "status", "--porcelain"], repo):
        raise ValueError("Dirty watcher checkout: " + name)
    run(["git", "fetch", "origin"], repo)
    approved = json.loads((ROOT / "receipts/approved-commits.json").read_text())[name]
    if run(["git", "rev-parse", "origin/main"], repo) != approved:
        raise ValueError("Source changed since watcher review: " + name)
    # The fixed branch and PR are recovered after an interrupted invocation.
    branch = "automation/reax92-start"
    remote = run(["git", "ls-remote", "--heads", "origin", branch], repo)
    if remote:
        run(["git", "checkout", "-B", branch, "origin/" + branch], repo)
        return repo, branch
    run(["git", "checkout", "-B", branch, "origin/main"], repo)
    if name in DESCRIPTORS:
        status_update(repo / DESCRIPTORS[name], receipt)
    else:
        build_run([sys.executable, "scripts/update-chain-status.py", "--live"], repo)
    validate_local(repo, name)
    run(["git", "diff", "--check"], repo)
    changed = run(["git", "diff", "--name-only"], repo).splitlines()
    if changed != [ALLOWED[name]]:
        raise ValueError("Unexpected status update paths: " + name)
    run(["git", "add", "--", ALLOWED[name]], repo)
    run(["git", "commit", "-m", "chore: confirm REAX netuid 92 chain start"], repo)
    run(["git", "push", "-u", "origin", branch], repo)
    return repo, branch


def merge_status(name, receipt):
    repo = REPOS / name
    recovered = json.loads(run(["gh", "pr", "list", "--head", "automation/reax92-start", "--state", "merged",
                               "--json", "url,mergeCommit"], repo))
    if recovered:
        run(["git", "fetch", "origin"], repo)
        oid = recovered[0]["mergeCommit"]["oid"]
        if run(["git", "rev-parse", "origin/main"], repo) != oid:
            raise ValueError("Merged status branch drift requires reconciliation")
        approved = json.loads((ROOT / "receipts/approved-commits.json").read_text())[name]
        if run(["git", "rev-parse", oid + "^"], repo) != approved:
            raise ValueError("Recovered merge has an unreviewed base")
        if run(["git", "diff", "--name-only", oid + "^", oid], repo).splitlines() != [ALLOWED[name]]:
            raise ValueError("Recovered merge has unexpected paths")
        assert_narrow_transition(repo, name, receipt, before_ref=oid + "^", after_ref=oid)
        return recovered[0]["url"]
    repo, branch = prepare_repo(name, receipt)
    prs = json.loads(run(["gh", "pr", "list", "--head", branch, "--state", "all",
                          "--json", "number,state,url"], repo))
    merged = next((p for p in prs if p["state"] == "MERGED"), None)
    if merged:
        return merged["url"]
    opened = next((p for p in prs if p["state"] == "OPEN"), None)
    if not opened:
        body = ROOT / "receipts" / (name + "-start-pr.md")
        body.write_text("Finalized Finney confirms REAX netuid 92 has started. Update chain status only; "
                        "source visibility, indexing, announcements and wallet/payment gates stay separate.\n\n"
                        "Local existing tests/build passed before push. Chain receipt: block "
                        + str(receipt["block"]) + " / " + receipt["block_hash"] + ".\n")
        created = run(["gh", "pr", "create", "--head", branch, "--base", "main", "--title",
             "Confirm REAX netuid 92 chain start", "--body-file", body], repo)
    number = opened["number"] if opened else int(created.rsplit("/", 1)[1])
    slug = "fstandhartinger/" + name
    pr = json.loads(run(["gh", "api", "repos/" + slug + "/pulls/" + str(number)], repo))
    pr["headRefOid"] = pr["head"]["sha"]
    pr["url"] = pr["html_url"]
    assert_head(repo, pr["headRefOid"])
    changed = [f["filename"] for f in json.loads(run(["gh", "api", "repos/" + slug + "/pulls/" + str(number) + "/files"], repo))]
    if changed != [ALLOWED[name]]:
        raise ValueError("Unexpected PR paths: " + name)
    assert_narrow_transition(repo, name, receipt)
    # Default gh merge observes protection/review gates; never --admin or bypass.
    slug = "fstandhartinger/" + name
    ci_gate(repo, name, pr["headRefOid"])
    # REST merge's sha precondition works with Sandy's old gh, and preserves protection.
    run(["gh", "api", "--method", "PUT", "repos/" + slug + "/pulls/" + str(pr["number"]) + "/merge",
         "-f", "merge_method=squash", "-f", "sha=" + pr["headRefOid"]], repo)
    proof = json.loads(run(["gh", "pr", "view", str(pr["number"]), "--json", "state,mergedAt"], repo))
    if proof["state"] != "MERGED":
        raise ValueError("Merge pending " + name)
    return pr["url"]


def assert_narrow_transition(repo, name, receipt, before_ref="origin/main", after_ref=None):
    """Recover only a branch whose exact JSON delta is the reviewed transition."""
    path = ALLOWED[name]
    before = json.loads(run(["git", "show", before_ref + ":" + path], repo))
    after = json.loads(run(["git", "show", after_ref + ":" + path], repo)) if after_ref else json.loads((repo / path).read_text())
    if name in DESCRIPTORS:
        expected = dict(before, updated=receipt["checked_at"][:10],
                        status=dict(before["status"], live=True, launch_status="live", chain=receipt, notes=LIVE_NOTE))
        if after != expected or after["status"]["netuid"] != 92:
            raise ValueError("Unexpected release/source/network or status delta")
    else:
        expected = dict(before, state="live", subnet_started=True, subtoken_enabled=True)
        if after != expected:
            raise ValueError("Site registration/source gate changed")


async def deploy_tool(name, args):
    # Platform wrapper owns the credential; agents never read the MCP env file.
    from mcp import ClientSession, StdioServerParameters
    from mcp.client.stdio import stdio_client
    async with stdio_client(StdioServerParameters(command="/usr/local/bin/sandy-deploy-mcp-client")) as (read, write):
        async with ClientSession(read, write) as session:
            await session.initialize()
            await session.call_tool("get_platform_overview", {})
            result = await session.call_tool(name, args)
            if result.is_error:
                raise ValueError("Deployment MCP refused operation")
            data = result.structured_content
            if data is None:
                data = json.loads(next(c.text for c in result.content if hasattr(c, "text")))
            if not data.get("ok"):
                raise ValueError("Deployment MCP failed")
            return data["data"]


def fetch_json(url):
    with urllib.request.urlopen(url, timeout=20) as response:
        return json.load(response)


def publish(receipt, state):
    for name in ("reax-miner-kit", "decisionmodels-mine-site", "reax-site"):
        if name not in state.setdefault("merged", {}):
            state["merged"][name] = merge_status(name, state["start_receipt"])
            atomic(STATE, state)
    for name, app in APPS.items():
        existing = state.setdefault("deployments", {}).get(name)
        if existing:
            rows = existing.get("deployments", []) if isinstance(existing, dict) else existing
            if isinstance(rows, dict):
                rows = [rows]
            for row in rows:
                uuid = row.get("deployment_uuid") if isinstance(row, dict) else None
                if uuid:
                    proof = asyncio.run(deploy_tool("get_deployment", {"deployment_uuid": uuid}))
                    status = proof.get("status", "")
                    if status in ("failed", "cancelled"):
                        attempts = state.setdefault("deploy_retries", {}).get(name, 0)
                        if attempts >= 2:
                            raise ValueError("Deployment failed after bounded retries: " + name)
                        state.setdefault("deployment_history", {}).setdefault(name, []).append(existing)
                        del state["deployments"][name]
                        state["deploy_retries"][name] = attempts + 1
                        atomic(STATE, state)
        if name not in state.setdefault("deployments", {}):
            key = "reax92-chain-start-" + name + "-" + str(state.get("deploy_retries", {}).get(name, 0))
            result = asyncio.run(deploy_tool("redeploy_application", {
                "application_uuid": app, "confirm": True, "idempotency_key": key}))
            state["deployments"][name] = result
            atomic(STATE, state)
    # Repeated timer runs recover queued deployments without sending another request.
    current = fetch_json("https://mine.decisionmodels.io/releases/current.json")
    site = fetch_json("https://reax.dev/chain-status.json")
    if current["status"]["live"] is not True or site["subnet_started"] is not True:
        raise ValueError("Waiting for live deployed chain descriptors")
    if current["status"]["netuid"] != 92 or site["netuid"] != 92:
        raise ValueError("Live descriptor target mismatch")
    state["published"] = True
    atomic(STATE, state)


def notify_once(receipt, state):
    run(["/home/flori/bin/agent-board", "inbox"])
    decisions = Path("/home/flori/DECISIONS.md").read_text()
    if not decisions:
        raise ValueError("Decisions unavailable")
    if not state.get("board_posted"):
        if state.get("board_intent"):
            raise ValueError("Ambiguous board post requires reconciliation")
        state["board_intent"] = True
        atomic(STATE, state)
        state["board_posted"] = run(["/home/flori/bin/agent-board", "post", "22",
            "REAX netuid 92 chain start confirmed at finalized block " + str(receipt["block"])
            + ". Alpha trading/epochs enabled; TAO emission flag=" + str(receipt["subnet_emission_enabled"])
            + ". Descriptors/sites updated automatically. Source/stealth/announcement holds unchanged.",
            "--kind", "finding"])
        atomic(STATE, state)
    if not state.get("notify_attempted"):
        # Persist intent before send: ambiguous delivery is held for manual reconciliation,
        # never automatically resent after a crash. Normal sent/queued receipts are retained.
        text = ("✅ ERLEDIGT\nWorum geht's: REAX Netuid 92 ist gestartet; Alpha-Handel und Alpha-Epochen "
                "sind aktiv, TAO-Emission " + ("freigeschaltet" if receipt["subnet_emission_enabled"] else "noch gesperrt")
                + "; Status automatisch aktualisiert: https://reax.dev/")
        run(["/home/flori/bin/notify", "now", "--requested", "--allow-german", "--dry-run", text])
        state["notify_attempted"] = datetime.now(timezone.utc).isoformat()
        atomic(STATE, state)
        try:
            state["notify_receipt"] = run(["/home/flori/bin/notify", "now", "--requested", "--allow-german", text])
        except subprocess.CalledProcessError as exc:
            state["notify_error"] = "notify exit " + str(exc.returncode) + "; reconcile receipt before resend"
            raise
        finally:
            atomic(STATE, state)
    elif not state.get("notify_receipt"):
        raise ValueError("Ambiguous/failed notification requires receipt reconciliation")


def main():
    ROOT.joinpath("receipts").mkdir(exist_ok=True)
    with ROOT.joinpath("receipts/watcher.lock").open("w") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        receipt = read_chain()
        atomic(ROOT / "receipts/chain-latest.json", receipt)
        state = json.loads(STATE.read_text()) if STATE.exists() else {}
        state["last_checked_at"] = receipt["checked_at"]
        atomic(STATE, state)
        if "--check-only" in sys.argv or not receipt["subtoken_enabled"]:
            print(json.dumps(receipt))
            return
        state.setdefault("start_receipt", receipt)
        if not state.get("confirmed_start"):
            candidate = state.get("candidate_start_block")
            state["candidate_start_block"] = receipt["block"]
            if candidate is None or receipt["block"] <= candidate:
                atomic(STATE, state)
                print("Start candidate recorded; waiting for a later finalized block")
                return
            state["confirmed_start"] = True
        atomic(STATE, state)
        if not state.get("published"):
            publish(receipt, state)
        notify_once(receipt, state)
        print(json.dumps(state))


if __name__ == "__main__":
    main()
