# Watcher validation

Finalized read-only chain check passed against Finney using SDK 11.3.0. Pending tick confirmed no publication or notification. Owner-only start/identity commands are text only.

Synthetic offline tests exercise wrong genesis/owner/netuid, stale block, typed flags, first-emission gate, preservation of source/image/testnet gates, refusal of a recovered registration-unlocking branch, and restart/notification ambiguity handling. Repository builds/tests are run under bubblewrap without network, the real HOME or credentials. The deployed transition itself cannot be run honestly before const starts the subnet; live-private builds are rehearsed with temporary copies and mocked chain/deploy/notification boundaries.

Before installation, approved source commit IDs are recorded in receipts/approved-commits.json. Future source drift fails closed pending review. State recovery tracks each merged PR, idempotent deployment, notification intent/receipt. Failed deployments get at most two new, recorded retries; ambiguous notifications are surfaced instead of resent. The watcher never bypasses GitHub review/protection.
