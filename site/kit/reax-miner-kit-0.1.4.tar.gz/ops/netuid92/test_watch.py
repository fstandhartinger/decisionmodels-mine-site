import copy
import json
import tempfile
import unittest
from datetime import datetime, timezone, timedelta
from pathlib import Path
from unittest.mock import patch

from chain_check import validate, OWNER, GENESIS
import watch


def receipt(live=False):
    return dict(genesis_hash=GENESIS, owner=OWNER, netuid=92, exists=True,
                subtoken_enabled=live, subnet_emission_enabled=False,
                registration_allowed=True, first_emission_block=9248652 if live else None,
                block=9248653, block_hash="0x" + "a" * 64,
                block_time=datetime.now(timezone.utc).isoformat(),
                checked_at=datetime.now(timezone.utc).isoformat())


class WatchTests(unittest.TestCase):
    def test_valid_pending_and_live_do_not_require_tao_flag(self):
        self.assertFalse(validate(receipt())["subtoken_enabled"])
        self.assertTrue(validate(receipt(True))["subtoken_enabled"])

    def test_wrong_owner_chain_or_bad_flags_fail_closed(self):
        for key, value in (("owner", "other"), ("genesis_hash", "wrong"),
                           ("exists", False), ("netuid", 93),
                           ("subtoken_enabled", "true"), ("subnet_emission_enabled", 1),
                           ("first_emission_block", None)):
            r = receipt(True)
            r[key] = value
            with self.assertRaises(ValueError):
                validate(r)

    def test_stale_receipt_refused(self):
        r = receipt(True)
        r["block_time"] = (datetime.now(timezone.utc) - timedelta(minutes=5)).isoformat()
        with self.assertRaises(ValueError):
            validate(r)

    def test_transition_preserves_release_and_stealth_gates(self):
        sample = json.loads((watch.REPOS / "reax-miner-kit/releases/current.json").read_text())
        before = copy.deepcopy(sample)
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "current.json"
            path.write_text(json.dumps(sample))
            watch.status_update(path, receipt(True))
            changed = json.loads(path.read_text())
        for key in set(before) - {"status", "updated"}:
            self.assertEqual(before[key], changed[key])
        self.assertTrue(changed["status"]["live"])
        self.assertEqual(changed["status"]["netuid"], 92)
        self.assertIsNone(changed["status"]["testnet_netuid"])
        self.assertFalse(changed["source"]["public"])
        self.assertFalse(changed["images"]["public"])

    def test_pending_tick_never_publishes_or_notifies(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            with patch.object(watch, "ROOT", root), patch.object(watch, "STATE", root / "state.json"), \
                    patch.object(watch, "read_chain", return_value=receipt()), \
                    patch.object(watch, "publish") as pub, patch.object(watch, "notify_once") as notify:
                watch.main()
                pub.assert_not_called()
                notify.assert_not_called()

    def test_restart_avoids_duplicate_publication_and_notification(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            state = {"published": True, "board_posted": "#123", "notify_attempted": "intent"}
            state["notify_receipt"] = "queued"
            with patch.object(watch, "ROOT", root), patch.object(watch, "STATE", root / "state.json"), \
                    patch.object(watch, "run", return_value="" ) as run:
                watch.notify_once(receipt(True), state)
                self.assertEqual(run.call_count, 1)  # freshness inbox read only

    def test_recovered_branch_cannot_change_source_or_registration(self):
        with tempfile.TemporaryDirectory() as tmp:
            repo = Path(tmp)
            path = repo / "dev/static/chain-status.json"
            path.parent.mkdir(parents=True)
            before = dict(network="Bittensor mainnet (finney)", netuid=92, state="pending",
                          subnet_started=False, subtoken_enabled=False, mainnet_registration_enabled=False,
                          testnet=dict(state="unassigned", netuid=None))
            after = dict(before, state="live", subnet_started=True, subtoken_enabled=True)
            path.write_text(json.dumps(after))
            with patch.object(watch, "run", return_value=json.dumps(before)):
                watch.assert_narrow_transition(repo, "reax-site", receipt(True))
                after["mainnet_registration_enabled"] = True
                path.write_text(json.dumps(after))
                with self.assertRaises(ValueError):
                    watch.assert_narrow_transition(repo, "reax-site", receipt(True))

    def test_notification_failure_records_ambiguity_and_never_resends(self):
        import subprocess
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            state = {"board_posted": "#123"}
            def fail_send(args, *a, **kw):
                if args[0].endswith("notify") and "--dry-run" not in args:
                    raise subprocess.CalledProcessError(1, args)
                return "preview"
            with patch.object(watch, "STATE", root / "state.json"), patch.object(watch, "run", side_effect=fail_send):
                with self.assertRaises(subprocess.CalledProcessError):
                    watch.notify_once(receipt(True), state)
                self.assertIn("notify_error", state)
                self.assertIn("notify_attempted", state)
                with self.assertRaises(ValueError):
                    watch.notify_once(receipt(True), state)

    def test_publisher_restarts_without_repeating_merged_prs_or_deploys(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            r = receipt(True)
            state = {"start_receipt": r}
            async def deploy(name, args):
                return {"deployments": [{"deployment_uuid": args["application_uuid"]}]} if name == "redeploy_application" else {"status": "finished"}
            def fetch(url):
                return {"status": {"live": True, "netuid": 92}} if "mine." in url else {"subnet_started": True, "netuid": 92}
            with patch.object(watch, "STATE", root / "state.json"), \
                    patch.object(watch, "merge_status", return_value="https://github.com/example/pr/1") as merge, \
                    patch.object(watch, "deploy_tool", side_effect=deploy) as mcp, \
                    patch.object(watch, "fetch_json", side_effect=fetch):
                watch.publish(r, state)
                self.assertTrue(state["published"])
                self.assertEqual(merge.call_count, 3)
                self.assertEqual(mcp.call_count, 2)
                watch.publish(r, state)
                self.assertEqual(merge.call_count, 3)
                self.assertEqual(mcp.call_count, 4)  # two read-only deployment polls

    def test_deployment_failure_retry_is_bounded_and_receipts_preserved(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            r = receipt(True)
            state = {"start_receipt": r, "merged": {name: "pr" for name in watch.ALLOWED},
                     "deployments": {"reax-site": {"deployments": [{"deployment_uuid": "bad"}]}},
                     "deploy_retries": {"reax-site": 2}}
            async def deploy(name, args):
                return {"status": "failed"} if name == "get_deployment" else {"deployments": []}
            with patch.object(watch, "STATE", root / "state.json"), patch.object(watch, "deploy_tool", side_effect=deploy):
                with self.assertRaises(ValueError):
                    watch.publish(r, state)
                self.assertEqual(state["deploy_retries"]["reax-site"], 2)
                self.assertEqual(state["deployments"]["reax-site"]["deployments"][0]["deployment_uuid"], "bad")

    def test_confirmed_unstarted_budget_job_uses_real_local_validation(self):
        check = dict(name="site", id=1, conclusion="failure")
        def api(args, *a, **kw):
            if args[0] == "git":
                return "head" if args[1] == "rev-parse" else ""
            endpoint = args[2] if args[1] == "api" and args[2] != "--method" else "post"
            if "/check-runs?" in endpoint:
                return json.dumps({"check_runs": [check]})
            if endpoint.endswith("annotations"):
                return json.dumps([dict(annotation_level="failure", message="The job was not started because an Actions budget is preventing further use.")])
            if "/actions/jobs/" in endpoint:
                return json.dumps({"steps": []})
            if endpoint.endswith("status"):
                return json.dumps({"statuses": [dict(state="success")]})
            return "{}"
        with patch.object(watch, "run", side_effect=api), patch.object(watch, "validate_local") as local:
            watch.ci_gate(Path("/tmp"), "decisionmodels-mine-site", "head")
            local.assert_called_once()

    def test_actual_failed_ci_is_never_overridden(self):
        def api(args, *a, **kw):
            if args[0] == "git":
                return "head" if args[1] == "rev-parse" else ""
            if "/check-runs?" in args[2]:
                return json.dumps({"check_runs": [dict(name="site", id=1, conclusion="failure")]})
            if args[2].endswith("annotations"):
                return json.dumps([dict(annotation_level="failure", message="Tests failed")])
            return json.dumps({"steps": [dict(name="Run tests", conclusion="failure")]})
        with patch.object(watch, "run", side_effect=api), patch.object(watch, "validate_local") as local:
            with self.assertRaises(ValueError):
                watch.ci_gate(Path("/tmp"), "decisionmodels-mine-site", "head")
            local.assert_not_called()

    def test_unvalidated_head_never_gets_success_status(self):
        with patch.object(watch, "run", return_value="different-head") as run, patch.object(watch, "validate_local") as local:
            with self.assertRaises(ValueError):
                watch.ci_gate(Path("/tmp"), "decisionmodels-mine-site", "expected-head")
            local.assert_not_called()
            self.assertEqual(run.call_count, 1)

    def test_recovered_descriptor_notes_must_equal_generated_transition(self):
        sample = json.loads((watch.REPOS / "reax-miner-kit/releases/current.json").read_text())
        with tempfile.TemporaryDirectory() as tmp:
            repo = Path(tmp)
            path = repo / "releases/current.json"
            path.parent.mkdir()
            path.write_text(json.dumps(sample))
            r = receipt(True)
            watch.status_update(path, r)
            after = json.loads(path.read_text())
            with patch.object(watch, "run", return_value=json.dumps(sample)):
                watch.assert_narrow_transition(repo, "reax-miner-kit", r)
                after["status"]["notes"] = "Launch is approved"
                path.write_text(json.dumps(after))
                with self.assertRaises(ValueError):
                    watch.assert_narrow_transition(repo, "reax-miner-kit", r)


if __name__ == "__main__":
    unittest.main()
