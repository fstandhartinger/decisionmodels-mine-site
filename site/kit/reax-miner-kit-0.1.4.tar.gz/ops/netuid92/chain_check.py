"""Wallet-free, finalized Finney reads using maintained Bittensor 11.3."""
import json
import re
from datetime import datetime, timezone

NETUID = 92
OWNER = "5GMxpAvB9iJkDtNDELhVn8GmbBz5XChnWcLaThWTJ38QmU6B"
GENESIS = "0x2f0555cc76fc2840a25a6ea3b9637146806f1f44b090c175ffde2a7e5ab36c03"


def validate(receipt):
    if receipt["genesis_hash"] != GENESIS or receipt["owner"] != OWNER:
        raise ValueError("Finney genesis or REAX owner mismatch; refusing transition")
    if receipt["netuid"] != NETUID or receipt["exists"] is not True:
        raise ValueError("REAX netuid 92 missing; refusing transition")
    for key in ("subtoken_enabled", "subnet_emission_enabled", "registration_allowed"):
        if type(receipt[key]) is not bool:
            raise ValueError("Invalid chain boolean: " + key)
    first = receipt["first_emission_block"]
    if receipt["subtoken_enabled"] and (type(first) is not int or first <= 0):
        raise ValueError("Started flag has no first-emission block; refusing transition")
    if type(receipt["block"]) is not int or receipt["block"] < 9247819:
        raise ValueError("Invalid finalized block")
    stamp = datetime.fromisoformat(receipt["block_time"])
    if stamp.tzinfo is None:
        raise ValueError("Unzoned finalized block timestamp")
    age = (datetime.now(timezone.utc) - stamp).total_seconds()
    if not -30 <= age <= 180:
        raise ValueError("Stale or future finalized chain read")
    if not isinstance(receipt["block_hash"], str) or not re.fullmatch(r"0x[0-9a-f]{64}", receipt["block_hash"]):
        raise ValueError("Invalid finalized block hash")
    return receipt


def read_chain():
    import bittensor as bt
    sub = bt.Subtensor(network="finney", retry_forever=False)
    try:
        block = sub.finalized_block
        info = sub.block_info(block)
        def query(name):
            return sub.query(getattr(bt.storage.SubtensorModule, name), [NETUID], block=block)
        receipt = {
            "netuid": NETUID, "network": "finney", "sdk": bt.__version__,
            "genesis_hash": sub.block_info(0).hash,
            "block": block, "block_hash": info.hash,
            "block_time": info.timestamp.isoformat(),
            "checked_at": datetime.now(timezone.utc).isoformat(),
            "exists": query("NetworksAdded"), "owner": query("SubnetOwner"),
            "subtoken_enabled": query("SubtokenEnabled"),
            "first_emission_block": query("FirstEmissionBlockNumber"),
            "subnet_emission_enabled": query("SubnetEmissionEnabled"),
            "registration_allowed": query("NetworkRegistrationAllowed"),
        }
        return validate(receipt)
    finally:
        sub.close()


if __name__ == "__main__":
    print(json.dumps(read_chain(), indent=2))
